import React from 'react';

export default function TestPage() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Test Page</h1>
      <p>This is a test page to check if React components are rendering correctly.</p>
    </div>
  );
}
